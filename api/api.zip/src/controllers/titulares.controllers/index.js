const getAllTitulares = require('./getAllTitulares.js');


module.exports = {
    getAllTitulares
}